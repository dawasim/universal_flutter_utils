/// [UFUButtonType] is used to set type of a button widget
enum UFUButtonType {
  /// Default type is [UFUButtonType.solid] is used to set solid type of a button widget
  solid,

  ///[UFUButtonType.outline] is used to set outline type of a button widget
  outline,
}
