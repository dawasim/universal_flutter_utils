enum ThumbSize {
  small,
  large,
}