enum UFUMultiSelectType {
  local,
  network
}