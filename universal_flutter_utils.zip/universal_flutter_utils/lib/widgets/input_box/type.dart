enum UFUInputBoxType {
  searchbar,
  withLabel,
  withLabelAndClearIcon,
  withoutLabel,
  searchbarWithoutBorder,
  composeEmail,
  inline,
  withLabelOutside,
}
