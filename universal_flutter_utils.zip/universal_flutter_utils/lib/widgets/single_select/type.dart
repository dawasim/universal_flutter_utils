
enum UFUSingleSelectType {
  network,
  local
}