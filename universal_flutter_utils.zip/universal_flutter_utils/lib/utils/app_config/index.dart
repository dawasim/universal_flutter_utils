class UFUAppConfig {
  static String appName = "app_name";
  static String appVersion = "app_version";
  static String baseUrl = "https://google.com";
  static String socketBaseUrl = "https://google.com";
  static String encryptionIV = "p2sQ1xJlwVSLXfxS";
  static String fcmToken = "";
}