
enum DeviceType {
  mobile,
  tablet,
  desktop
}