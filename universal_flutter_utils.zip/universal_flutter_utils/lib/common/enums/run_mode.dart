enum RunMode {
  app,
  unitTesting,
  integrationTesting,
}