
enum UFUNetworkMultiSelectType {
  get,
  post
}