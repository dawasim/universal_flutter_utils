/// [UFUFontFamily] is used to change the font of the text.
enum UFUFontFamily {
  /// Default font is [UFUFontFamily.roboto] is used to set font of a text widget
  // roboto,

  ///  [UFUFontFamily.montserrat] is used to set font of a text widget
  // montserrat,

  ///  [UFUFontFamily.productSans] is used to set font of a text widget
  productSans,
}
