
class PaginationConstants {

  static const pageLimit = 20;
  static const pageLimit250 = 250;
  static const pageLimit50 = 50;
  static const pageLimit10 = 10;
  static const noLimit = 0;

}