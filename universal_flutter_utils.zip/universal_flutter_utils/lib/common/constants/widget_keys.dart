class UFUWidgetKeys {
  static const String quickActionsKey = "quick_actions";
}